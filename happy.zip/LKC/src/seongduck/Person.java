package seongduck;

public class Person {
	
	double money = 0;
	
	double happyness =0;
	
	}


