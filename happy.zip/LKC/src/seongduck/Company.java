package seongduck;

public class Company {

	static double payPerDay= 100;
	
	public static double work()
	{
				
		return payPerDay * 10; //payPerDay*workday
	}
}
