package JavaBasicExam;

public class GambleDice {

	public static void main(String[] args) {
		
		// ຜົນລວມຂອງເງິນໂດລາທີ່ຫາໄດ້
		double dolar = dice()+dice()+dice();
		// ປ່ຽນໂດລາເປັນ KIP
		double kip = exchange(dolar);
		
		// ຜົນໄດ້ຮັບ
		System.out.println("total dolar : $"+dolar);
		System.out.println("total kip : "+ kip +"KIP");
			
	}

public static int dice() {
	
	return (int) (Math.random()*5)+1;   // 1~6 
}

public static double exchange(double dolar) {
	
	return dolar*9900;
}
	
}
