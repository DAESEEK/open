package JavaBasicExam;

import java.util.Scanner;

public class ConApp {

	static int times;
	static int human;
	static int count = 0;

	public static void printOut() {

		for (int i = 1; i < times + 1; i++) {

			int gamerAi = (int) ((Math.random() * 3) + 1);
			if (gamerAi == 2 && human == 1 || gamerAi == 1 && human == 3 || gamerAi == 3 && human == 2) {
				System.out.println(human + " : " + gamerAi);

				count++;
			} else {

				System.out.println(human + " : " + gamerAi);

			}

		}

		System.out.println(" you win " + count + "times!");

	}

	public static void main(String[] args) {

		System.out.println("Enter the number!(1 to 3) ");

		Scanner scanner = new Scanner(System.in);
		human = scanner.nextInt();

		System.out.println("Enter the the times ");
		Scanner scanner1 = new Scanner(System.in);

		times = scanner.nextInt();

		printOut();

	}
}
