package JavaBasicExam;

public class Gasoline {

	public static void main(String[] args) {
		double gasoline = 8.86;
		
		double distance = 182.736;
		
		double Effiency = calcEffiency (gasoline, distance);
		

		System.out.println("Usage per 1L : "+Effiency+"KM");
		
				
		
	}
public static double calcEffiency(double gasoline,double distance) {
	
	return gasoline/distance;
}
	
	
}
