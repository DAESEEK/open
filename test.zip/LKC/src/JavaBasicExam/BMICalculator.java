package JavaBasicExam;

public class BMICalculator {

	// ການຄິດໄລ່ BMI 
	public static double calculatorBMI(double weight,double tall ) {
		
		return 0;
	}
	// ຜົນຜະລິດອ້ວນ FAT rate
	public static void printBMI(double bmi) {
		
		
	}
	
	  // ຈຸດເລີ່ມຕົ້ນຂອງໂຄງການ
	public static void main(String[] args) {
	  // ນ້ ຳໜັກ    ກຸນແຈ
		
		//BMI
		
		
		
		

	}

}
