package JavaBasicExam;

import java.util.Scanner;

public class CalculateCal {
	
	static double kcal;

	public static void main(String[] args) {
		
		
		Scanner scanner = new Scanner(System.in);
		
		kcal = scanner.nextInt();
	
		System.out.println("Used Kcal : "+ kcal +"Kcal");
				
		}

	public static double calculateWalkingKcal(int walkingCount) {
		
		return walkingCount*0.02;
	}
	
	
	}



