package JavaBasicExam;

import java.util.Scanner;

public class DrawstarTree {

	public static void main(String[] args) {

		System.out.print("Enter the line number : ");

		Scanner scanner = new Scanner(System.in);

		int countLine = scanner.nextInt();

		for (int i = 0; i <= countLine; i++) {

			for (int j = countLine; j > 0; j--) {

				if (i < j) {

					System.out.print(" ");

				} else {

					System.out.print("*");

				}

			}
			System.out.println(" ");
		}

		for (int i = 0; i <= countLine; i++) {

			for (int j = 0; j < i; j++) {

				System.out.print("*");

			}
			System.out.println(" ");
		}

	}
}
