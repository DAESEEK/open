package JavaBasicExam;

public class HelloApp {

	public static void main(String[] args) {
		
		System.out.println("hello!!");
		

		int a = 3;
		
		String g = Integer.toString(a);
		
		
		System.out.println(a);
		System.out.println(g);
		
		
		

	}

}
