package JavaBasicExam;

public interface gamerAi {

}
