package JavaBasicExam;

import java.util.Scanner;

public class DrawStar1 {

	public static void main(String[] args) {

		System.out.println("Enter the Line Number : ");
		Scanner scan = new Scanner(System.in);

		int countLine = scan.nextInt();

		for (int i = 0; i <= countLine; i++) {

			for (int j = 0; j < countLine; j++) {
				System.out.print("*");
				
			}
			
			System.out.println(" ");
		}
	

	}

}
