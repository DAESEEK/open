package JavaBasicExam;

public class GameKaweBaweBo {


	
	public static int winCount() {
		return winCount();
	}

	static int a = 0;



	public static int gamerCom() {
		
		
		return (int) (Math.random()*3)+1;
	}
	

	public static int human() {
		
		return 3;
	}
	
	public static int playCount() {
		
		return 10;
	}
	
	
	
	public static void printResult () {
		
	
		for(int i =1; i < playCount()+1; i++) {
		
		System.out.println(human()+"  "+gamerCom());
		
		
		if(human()==3 && gamerCom()==1 )
			//	||human()==2 && gamerCom()==1||human()==3 && gamerCom()==1) 
			{
			
				a=a+1;
						 
		}
		else {
			a=a+0;
		}
			System.out.println(a);
		}
				
		
	}
	
	

	public static void main(String[] args) {
	
	  
		
		
		printResult();
		
		
		
		
	}

}
